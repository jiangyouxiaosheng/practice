using UnityEngine;
public enum ItemType
{
    Seed,
    Commodity,
    Furniture,
    HoeTool,//��ͷ
    ChopTool,//��ͷ
    BreakTool,//����
    ReapTool,//����
    WaterTool,//ˮͰ
    CollectTool,//����
    ReapableScenery//�Ӳ�

}
public enum SlotType
{
    Bag,
    Box,
    Shop
}
public enum InventoryLocation
{
    Player,Box
}


