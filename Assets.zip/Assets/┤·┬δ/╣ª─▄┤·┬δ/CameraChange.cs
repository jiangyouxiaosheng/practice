using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class CameraChange : MonoBehaviour
{
    public GameObject camera3D;   
    public GameObject camera2D;
    public GameObject cameraChange;
    private bool jc = false;   //�������Ƿ��ڴ˷�����
    private bool xj = false;   //�ж�Ŀǰ���״̬
    private void Update()
    {
        //������л�
        if (jc == true)
        {
            if ( Input.GetKeyDown(KeyCode.E))
            {
                camera3D.SetActive(false);
                camera2D.SetActive(true);
                xj = true;
            }
        }
        if(xj)
        {
            if(Input.GetKeyDown(KeyCode.Q))
            {   
                camera3D.SetActive(true);
                camera2D.SetActive(false);
                xj = false;
            }
        }    
    }
   
    private void OnCollisionStay(Collision other)
    {
        
        if (other.gameObject.CompareTag("Player"))   //������
        {
           // cameraChange.SetActive(true);

            jc = true;
        }
    }
    private void OnCollisionExit(Collision collision)
    {
 
        //cameraChange.SetActive(false);
        jc = false;

    }
   
}
 
