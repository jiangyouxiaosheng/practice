using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;


public class GameManager : MonoBehaviour
{
    static GameManager instance;

    List<Orb> orbs;

    float gameTime;
    //public  int orbNum; 
    public int deadnum; 
    private void Awake()
    {
        if(instance != null)
        {
            Destroy(gameObject);
            return;
        }
        instance = this;

        orbs = new List<Orb>();

        DontDestroyOnLoad(this);
    }
    private void Update()
    {
        gameTime += Time.deltaTime;
        UIManager.UpdateTimeUI(gameTime);
    }
    public static void RegisterOrb(Orb orb)
    {
      if(!instance.orbs.Contains(orb)) 
      { 
          instance.orbs.Add(orb);
      }
        UIManager.UpdateOrbUI(instance.orbs.Count);
    }
    public static void PlayerGroundOrb(Orb orb)
    {
        if(!instance.orbs.Contains(orb))
        return;
        instance.orbs.Remove(orb);
        UIManager.UpdateOrbUI(instance.orbs.Count);
    }
    public static void PlayerDied()
    {
         instance.deadnum++;
         instance.Invoke("RestartScene",1.5f);
        UIManager.UpdateDeathUI(instance.deadnum);
    }
    void RestartScene()
    {
        instance.orbs.Clear();
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }

}