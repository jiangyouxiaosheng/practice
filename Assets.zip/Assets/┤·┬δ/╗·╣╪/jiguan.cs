using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class jiguan : MonoBehaviour
{
    
    public GameObject c2d;
   
    void Start()    
    {
        
    }

    // Update is called once per frame
    [System.Obsolete]
    void Update()
    {
        if(c2d.active == false)
        {
            transform.position = new Vector3(-5f, 0f, -4f);
            
        }
        else
        {
            transform.position = new Vector3(0.15f, 0f, -4f);
        }
        
     
    }

}
