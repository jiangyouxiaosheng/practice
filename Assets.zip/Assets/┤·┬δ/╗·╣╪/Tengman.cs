using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Tengman : MonoBehaviour
{
    [SerializeField] Animator anim;

    // public GameObject fKey;
    public float radius;
    public bool stone;

    void Update()
    {
        FoundPlayer();

    }

    private void FoundPlayer()
    {
        //���η�Χ�����
        var colliders = Physics.OverlapSphere(transform.position, radius);
        foreach (var target in colliders)
        {
            if (target.CompareTag("Player"))
            {


                if (Input.GetKey(KeyCode.F))
                {
                    stone = true;
                    anim.SetBool("Tengman", true);
                }
            }
            else
            {


            }
        }
    }


    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, radius);
    }
}
