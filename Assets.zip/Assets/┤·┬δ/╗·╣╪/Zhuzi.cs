using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Zhuzi : MonoBehaviour
{
       
public GameObject c2d;
void Start()    
{
    
}
// Update is called once per frame
[System.Obsolete]
void Update()
{
    if(c2d.active == false)
    {
        transform.position = new Vector3(-7f, -5f, 43f);
        
    }
    else
    {
        transform.position = new Vector3(0f, -5f, 43f);
    }
    
 
}
       
}
