using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HaKo : MonoBehaviour
{
    private bool Move = false;
    public GameObject Player;
    private Vector3 startPos = default;
    private Vector3 startPosBox = default;
    private bool isPush = false;
     void Start()
    {
      
    }
    // Start is called before the first frame update
    private void Update()
    {
        if (isPush)
        {
            float x = this.startPosBox.x + Player.transform.localPosition.x - startPos.x;
            
            float z = this.startPosBox.z + Player.transform.localPosition.z - startPos.z;
            this.transform.localPosition = new Vector3(x,this.transform.localPosition.y,z);// this.startPosBox + Player.transform.localPosition - startPos;
            Debug.Log("2");
        }
        


    }

    // Update is called once per frame

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.other.gameObject.CompareTag("Player"))
        {
            this.startPos = Player.transform.localPosition;
            this.startPosBox = this.transform.localPosition;
            isPush = true;
            Debug.Log("1");
        }
    }
    private void OnCollisionExit(Collision collision)
    {
        if (collision.other.gameObject.CompareTag("Player"))
        {
            isPush = false;
        }
    }
}
