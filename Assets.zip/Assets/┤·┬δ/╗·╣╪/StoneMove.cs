using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StoneMove : MonoBehaviour
{
    public GameObject Stone;
    // Start is called before the first frame update
    private void OnCollisionStay(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player") && Stone.transform.position.z < 28f)
        {
            Debug.Log("1");
            Stone.transform.position = new Vector3(Stone.transform.position.x, Stone.transform.position.y, Stone.transform.position.z + 0.1f);
        }
    }
}
