using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Stone : MonoBehaviour
{

    public GameObject Fa;
    public GameObject cube1;
    public GameObject cube2; 
 
 
    Rigidbody rb;
    //public GameObject Player;
    //[SerializeField]PlayerCheck door;
    void Start()
    {
        rb = GetComponent<Rigidbody>();
        
    }
    void FixUpdate(){
        Fa.transform.position = this.transform.position;
        cube1.transform.position = this.transform.position;
        cube2.transform.position = this.transform.position;

    }

    private void OnCollisionEnter(Collision collision)
    {
        Debug.Log("yes");
        if (collision.gameObject.CompareTag("Player") )
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z+0.1f);
        }
    }




}
