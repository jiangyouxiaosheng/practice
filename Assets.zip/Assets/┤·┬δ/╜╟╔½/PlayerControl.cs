using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerControl : MonoBehaviour
{
    private Rigidbody rb;
    private CapsuleCollider coll;
    private Animator anim;
    public GameObject Hako;

    //[Header("�ƶ�����")]
    public float moveSpeed = 0;
    private float speedPd;
    public float jumpForce;
    private int jumpNub = 1;
    public Transform mesh;
    private Quaternion targerRot;
   

   // [Header("�������")]
    public GameObject camera3D;
    public GameObject camera2D;
    private bool cameraChange = false;



    private void Awake()
    {
        anim = GetComponent<Animator>();
    }

    private void Start()
    {
        rb = GetComponent<Rigidbody>();
        // coll = GetComponent<CapsuleCollider>();
        transform.GetComponent<Rigidbody>().constraints = RigidbodyConstraints.FreezeRotation;

    }
    private void FixedUpdate()
    {
        /*if (cameraChange == true)
        {
            transform.GetComponent<Rigidbody>().constraints =  RigidbodyConstraints.FreezePositionX | RigidbodyConstraints.FreezeRotation;
        }
        else if(cameraChange == false)
        {
            transform.GetComponent<Rigidbody>().constraints =  RigidbodyConstraints.FreezeRotation;
        }*/
    
    }
    private void Update()
    {
       CameraChange();
       Movement3D();
       SwitchAnimation();

    }

  
    void Movement3D()
    {
        float h = Input.GetAxis("Vertical");
        float v = Input.GetAxis("Horizontal");
        Vector3 dir = new Vector3(-h, 0, v);
        if (!(h == 0 && v == 0))
        {
            targerRot = Quaternion.LookRotation(dir);
            speedPd = 1f;
        }
        else
        {
            speedPd = 0f;
        }

        transform.Translate(dir * Time.deltaTime * moveSpeed,Space.World);
        mesh.rotation = Quaternion.Lerp(mesh.rotation, targerRot, 0.03f);
        //float h = Input.GetAxis("Horizontal");
        //float v = Input.GetAxis("Vertical");
        //Vector3 dir = new Vector3(h, 0, v);
        //if (h != 0 || v != 0)
        //{
        //  //  rb.velocity = new Vector3(-h * moveSpeed, rb.velocity.y, v * moveSpeed);
        //    targerRot = Quaternion.LookRotation(dir);
        //}
       
       
        
        if (Input.GetButtonDown("Jump")&&jumpNub == 1 )
        {
            
            rb.velocity = new Vector3(rb.velocity.x, jumpForce, rb.velocity.z);
            jumpNub--;
        }

    }
   
    void CameraChange()
    {
        if(Input.GetKeyDown(KeyCode.Q))
        {
            camera3D.SetActive(false);
            camera2D.SetActive(true);
            rb.transform.position = new Vector3(0.3f, rb.transform.position.y, rb.transform.position.z);
            cameraChange =true;
            
        }
        else if(Input.GetKeyDown(KeyCode.E))
        {
            camera3D.SetActive(true);
            camera2D.SetActive(false);
            cameraChange =false;
            

        }

    }
    private void SwitchAnimation()
    {
        anim.SetFloat("Speed", speedPd);
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.other.gameObject.CompareTag("Ground"))
        {
            jumpNub = 1;
        }
        if (collision.other.gameObject.CompareTag("Hako"))
        {
            Hako.transform.parent = this.transform;
            anim.SetBool("Push", true);
        }


    }
    private void OnCollisionExit(Collision collision)
    {
        if (collision.other.gameObject.CompareTag("Ground"))
        {
            jumpNub = 0;
        }
        if (collision.other.gameObject.CompareTag("Hako"))
        {
            anim.SetBool("Push", false);
        }
    }
}
