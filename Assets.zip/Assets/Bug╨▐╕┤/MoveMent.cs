using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveMent : MonoBehaviour
{
    public float speed = 3f;
   
   // public Transform point;
    
    
   

   // public Transform mesh;
    // Start is called before the first frame update
    void Start()
    {
   
    }

    // Update is called once per frame
    void Update()
    {
        float h = Input.GetAxis("Horizontal");
        float v = Input.GetAxis("Vertical");
        Vector3 dir = new Vector3(h, 0, v);
        //dir = point.TransformDirection(dir);
        //if (!(h == 0 && v == 0))
        //    mesh.rotation = Quaternion.LookRotation(dir);
        transform.Translate(dir * Time.deltaTime * speed);
    
       
        
    }
}
