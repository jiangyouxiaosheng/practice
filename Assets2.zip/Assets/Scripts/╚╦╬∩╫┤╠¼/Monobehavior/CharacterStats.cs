using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CharacterStats : MonoBehaviour
{
    public CharaData_SO charaData;
    public AttackData_SO attackData;
    [HideInInspector]
    public bool isCritical;
    #region Read form Data_SO

    public int Maxhealth
    {
        get{ if (charaData != null)return charaData.maxHealth; else return 0; }
        set{ charaData.maxHealth = value; }
    }

    public int CurrentHealth
    {
        get { if (charaData != null) return charaData.currentHealth; else return 0; }
        set { charaData.currentHealth = value; }
    }

    public int BaseDefence
    {
        get { if (charaData != null) return charaData.baseDefence; else return 0; }
        set { charaData.baseDefence = value; }
    }

    public int CurrentDefence
    {
        get { if (charaData != null) return charaData.currentDefence; else return 0; }
        set { charaData.currentDefence = value; }
    }
    #endregion
}
