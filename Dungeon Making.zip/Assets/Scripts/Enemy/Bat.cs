using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Bat : Enemy
{
    
    
    
    // Start is called before the first frame update
    void  Start()
    {
        base.Start();
        

    }

    // Update is called once per frame
    void Update()
    {
        base.Update();
     


    }
    private void FixedUpdate()
    {
        transform.position = new Vector3(transform.position.x - 0.01f, transform.position.y, transform.position.z);
    }
   
    

}
