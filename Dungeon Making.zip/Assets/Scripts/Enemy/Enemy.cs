using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int enemyHp;
    public int enemyATK;
    private SpriteRenderer sr;
    private Color cl;
    public float flashTime;
    public GameObject blooodEffect;
    private PlayerHealth playerHealth;
    private CapsuleCollider2D cap2D;
    private Animator anim;
    private Rigidbody2D rb;


    // Start is called before the first frame update
    public void Start()
    {
        cap2D = GameObject.FindGameObjectWithTag("Player").GetComponent<CapsuleCollider2D>();
        playerHealth = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerHealth>();
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();
        sr = GetComponent<SpriteRenderer>();
        cl = sr.color;
    }

    // Update is called once per frame
    public void Update()
    {
        if (enemyHp <= 0)
        {
            Destroy(gameObject);
        }
        TimeStop();


    }
    public void TakeDamage(int PlayerATK)
    {
        enemyHp -= PlayerATK;
        FlashColor(flashTime);
        Instantiate(blooodEffect, transform.position, Quaternion.identity);
        GameController.camShake.Shake();
    }
    void FlashColor(float time)
    {
        sr.color = Color.red;
        Invoke("ResetColor", time);
    }
    private void ResetColor()
    {
        sr.color = cl;
    }
    private void TimeStop()
    {
        if (TimeManager.timeStop == true)
        {

            anim.speed = 0.1f;
            Invoke("TimeStopCD", 3f);
        }
        else if(TimeManager.timeStop == false)
        {
            anim.speed = 1f;
        }


    }
    void TimeStopCD()
    {
        TimeManager.timeStop = false;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        
        if (collision.gameObject.CompareTag("Player")&&collision.GetType().ToString() == "UnityEngine.CapsuleCollider2D")   
        {
            if (playerHealth != null)
            {
                playerHealth.DamegePlayer(enemyATK);
            }
        }
    }
}
