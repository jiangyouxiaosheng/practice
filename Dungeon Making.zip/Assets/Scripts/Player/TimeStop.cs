using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TimeStop : MonoBehaviour
{

    private CapsuleCollider2D Cap2D;
    private void Start()
    {
        Cap2D = GetComponent<CapsuleCollider2D>();

        
    }
    private void Update()
    {
        Invoke("DsThis", 0.7f);
        
    }


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            Time.timeScale = 0.3f;
            Invoke("TimeFalsh", 0.1f);
           
            TimeManager.timeStop = true;
                


        }
    }
    void DsThis()
    {
        Destroy(gameObject);
    }
    void TimeFalsh()
    {
        Time.timeScale = 1f;
    }
    void TimeStopCD()
    {
        TimeManager.timeStop = false;
    }
}
