using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public float moveSpeed;
    private float moveX;



    //��Ծ����
    public float jumpForce;
    public int jumpNum=2;

    //�ж��Ƿ��ڵ�����
    public bool isGround;
    

    public LayerMask groundLayer;
    public LayerMask wallLayer;

    //���
    public float dashTime;
    private float dashTimeLeft;
    public float dashSpeed;
    private float laseDash = -10f;
    public float dashCD;
    private CapsuleCollider2D cap2D;
    public GameObject timeStop;

    //��ǽ��
    bool isTouchingFront; //�Ƿ���ǽ��
    public Transform frontCheck;  //�жϵ�
    bool wallSliding;  
    public float wallSlidingaSpeed; //���»�

    bool wallJumping;
    public float xWallForce;
    public float yWakkForce;
    public float wallJumpTime;




    public bool isDash,isRun;
   


    private Rigidbody2D rb;
    private Animator anim;
    private BoxCollider2D boxColl;
    public float faceDircetion;
    private PlayerHealth playerHp;



    // Start is called before the first frame update
    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        anim = GetComponent<Animator>();
        boxColl = GetComponent<BoxCollider2D>();
        cap2D = GetComponent<CapsuleCollider2D>();
        playerHp = GetComponent<PlayerHealth>();




    }

    // Update is called once per frame
    void Update()
    {
        if ( playerHp.health !> 0)
        {
            MoveControl();
            CheckGround();
            Jump();
            SwitchAnimation();
            Dash();
            CheckWall();

        }

    }
    private void FixedUpdate()
    {
        DashSpeeed();
    }
    private void MoveControl() //��ҵ��ƶ�
    {
         moveX = Input.GetAxis("Horizontal");
       
         faceDircetion = Input.GetAxisRaw("Horizontal");
        if (faceDircetion!=0)
        {
            transform.localScale = new Vector3(faceDircetion, 1, 1);
            
        }
        Vector2 playerMove = new Vector2(moveX * moveSpeed, rb.velocity.y);
        rb.velocity = playerMove;
        //�ܶ��ж�
        isRun = Mathf.Abs(rb.velocity.x) > Mathf.Epsilon;
        anim.SetBool("Run", isRun);
        

    }

    //�ж�����Ƿ��ڵ�����
    private void CheckGround()
    {
        isGround = boxColl.IsTouchingLayers(LayerMask.GetMask("Ground"));
    }
    private void Jump()
    {
      if(isGround)
      {
            jumpNum = 1;
      }
      if(Input.GetButtonDown("Jump")&&jumpNum > 0)
      {
            anim.SetBool("Jump", true);
            rb.AddForce(new Vector2(0, jumpForce),ForceMode2D.Impulse);

            jumpNum--;
      }
      if(Input.GetButtonDown("Jump")&& jumpNum ==0 &&isGround)
      {
            anim.SetBool("Jump", true);
            Vector2 jumpVel = new Vector2(0.0f, jumpForce);
            rb.velocity = Vector2.up * jumpVel;

      }
    }

  
    private void SwitchAnimation()
    {
        anim.SetBool("Idle", false);
        if (anim.GetBool("Jump"))
        {
            if (rb.velocity.y < 0.0f)
            {
                anim.SetBool("Jump", false);
                anim.SetBool("Fall", true);
            }
        }
        else if(isGround)
        {
            anim.SetBool("Fall", false);
            anim.SetBool("Idle", true);
        }
    }
    private void Dash()
    {
        if (Input.GetKeyDown(KeyCode.L))
        {
            Instantiate(timeStop, new Vector3(this.transform.position.x,this.transform.position.y,this.transform.position.z),Quaternion.identity);
            
            if(Time.time>=(laseDash + dashCD))
            {
                isDash = true;
                dashTimeLeft = dashTime;
                laseDash = Time.time;
            }
        }
    }
    void DashSpeeed()
    {
      
        if (isDash )
        {
            if(dashTimeLeft > 0)
            {
                rb.velocity = new Vector2(dashSpeed * faceDircetion, rb.velocity.y);
                dashTimeLeft -= Time.deltaTime;
                ShadowPool.instance.GetFormPool();
                cap2D.enabled = false;
            }
        }
        if (dashTimeLeft <= 0)
        {
            isDash = false;
            cap2D.enabled = true;
                }
    }

    void CheckWall()
    {
        isTouchingFront = Physics2D.OverlapCircle(frontCheck.position, 0.1f, wallLayer);
        if (isTouchingFront == true && isGround == false && moveX != 0)
        {
            wallSliding = true;
        }
        else
        {
            wallSliding = false;
        }
        if (wallSliding)
        {
            rb.velocity = new Vector2(rb.velocity.x, Mathf.Clamp(rb.velocity.y, -wallSlidingaSpeed, float.MaxValue));
            wallJumping = true;
            Invoke("SetWallJumpingToFalse", wallJumpTime) ;
        }
        if (wallJumping == true&&Input.GetKeyDown(KeyCode.Space))
        {
            rb.velocity = new Vector2(xWallForce * -moveX, yWakkForce);
        }
        
    }
    void SetWallJumpingToFalse()
    {
        wallJumping = false;
    }

}
