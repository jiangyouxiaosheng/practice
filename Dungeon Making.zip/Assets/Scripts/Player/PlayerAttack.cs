using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerAttack : MonoBehaviour
{
    public int damage;
    public float attackCd;
    private bool attackCk = true;

    private Animator anim;
    private PolygonCollider2D coll;

    private void Start()
    {
        anim = GetComponentInParent<Animator>();
        coll = GetComponent<PolygonCollider2D>();

    }
    private void Update()
    {
        Playerattack();
        AttackCd();
       
    }
    private void Playerattack()
    {
        if (Input.GetKeyDown(KeyCode.J) && attackCk == true)
        {
            
            anim.SetTrigger("Attack");
            StartCoroutine(AttackCd());
            StartCoroutine(StartAttack());
            attackCk = false;
        }
    }
    IEnumerator AttackCd()
    {
        yield return new WaitForSeconds(0.6f);
        attackCk = true;
    }
    IEnumerator StartAttack()
    {
        yield return new WaitForSeconds(0.15f);
        coll.enabled = true;
        StartCoroutine(DisableHitBox());
    }
    IEnumerator DisableHitBox()
    {
        yield return new WaitForSeconds(0.2f);
        coll.enabled = false;
    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
       if( collision.CompareTag("Enemy"))
       {
            collision.GetComponent<Enemy>().TakeDamage(damage);
       }
    }

}
