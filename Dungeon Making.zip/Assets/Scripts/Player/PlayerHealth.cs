using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerHealth : MonoBehaviour
{
    public int health;
    public int numBlinks;
    public float seconds;
  

    private Renderer myRender;
    private Animator anim;

    


    private void Start()
    {
        myRender = GetComponent<Renderer>();
        anim = GetComponent<Animator>();
    }
    private void Update()
    {
        
    }

    public void DamegePlayer(int damege)
    {
        health -= damege;



        if (health <= 0)
        {
            anim.SetTrigger("Die");
            
            Invoke("PlayerDide", 1f);

        }
        BlikPlayer(numBlinks, seconds);

    }
   
     void PlayerDide()
    {
        Destroy(gameObject);
    }
    private void BlikPlayer(int numBlinks, float seconds)
    {
        StartCoroutine(DoBlinks(numBlinks, seconds));
    }
    IEnumerator DoBlinks(int numBlinks, float seconds)
    {
        for (int i = 0; i < numBlinks * 2; i++)
        {
            myRender.enabled = !myRender.enabled;
            yield return new WaitForSeconds(seconds);
        }
        myRender.enabled = true;
        }

    }
