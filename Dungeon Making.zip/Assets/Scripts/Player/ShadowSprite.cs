using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ShadowSprite : MonoBehaviour
{
    private Transform player;

    private SpriteRenderer thisSprite;
    private SpriteRenderer playerSpritel;

    private Color cl;

    //ʱ�����
    public float activeTime;
    public float activeStart;


    //��͸���ȿ���
    private float alpha;
    public float alphaSet;
    public float alphaMultiplier;

    // Update is called once per frame
    private void OnEnable()
    {
        player = GameObject.FindGameObjectWithTag("Player").transform;
        thisSprite = GetComponent<SpriteRenderer>();
        playerSpritel = player.GetComponent<SpriteRenderer>();

        alpha = alphaSet;
        thisSprite.sprite = playerSpritel.sprite;
        transform.position = player.position;
        transform.localPosition = player.localScale;
        transform.rotation = player.rotation;

        activeStart = Time.time;
    }
    void Update()
    {
        alpha *= alphaMultiplier;
        cl = new Color(1f, 0.5f, 0.5f, alpha);
        thisSprite.color = cl;


        if(Time.time>=activeStart + activeTime)
        {
            //���ض����
            ShadowPool.instance.ReturnPool(this.gameObject);
        }
    }
}
